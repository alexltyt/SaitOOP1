"""4.	Write a Python program to print a specified list after removing the 0th, 4th and 5th elements."""

list1 =  ['Red', 'Green', 'White', 'Black', 'Pink', 'Yellow']

del list1[0]
del list1[3:5]

print(list1)